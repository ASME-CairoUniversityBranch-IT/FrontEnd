import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ProjectsService } from '../../../core/services/projects.service';
import { WorkshopProject, ProjectType } from '../../../core/models/project.model';
import { ProjectHeroComponent } from '../../../shared/components/project-hero/project-hero';
import { ProjectGalleryComponent } from '../../../shared/components/project-gallery/project-gallery';
import { ProjectDetailsComponent } from '../../../shared/components/project-sidebar-details/project-sidebar-details';
import { ReservationComponent } from '../../../shared/components/reservation/reservation';
import { InstructorsComponent } from '../../../shared/components/instructors/instructors';

@Component({
  selector: 'app-workshop-detail',
  standalone: true,
  imports: [
    CommonModule, ProjectHeroComponent, ProjectGalleryComponent,
    ProjectDetailsComponent, ReservationComponent, InstructorsComponent,
  ],
  templateUrl: './workshop-detail.html',
  styleUrls: ['./workshop-detail.css', '../../../shared/styles/project-detail-layout.css'],
})
export class WorkshopDetailComponent implements OnInit {
  project: WorkshopProject | null = null;
  loading = true;
  notFound = false;

  constructor(private route: ActivatedRoute, private projectsService: ProjectsService) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.projectsService.getById(id).subscribe({
      next: p => {
        this.loading = false;
        if (p.type === ProjectType.Workshop) this.project = p;
        else this.notFound = true;
      },
      error: () => { this.loading = false; this.notFound = true; },
    });
  }
}
