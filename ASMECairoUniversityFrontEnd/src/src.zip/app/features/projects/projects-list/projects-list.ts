import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ProjectsService } from '../../../core/services/projects.service';
import { ProjectSummary, ProjectType } from '../../../core/models/project.model';
import { ALL_PROJECT_TYPES, projectDetailPath, projectTypeIcon, projectTypeLabel } from '../../../core/utils/project-route.util';

type TypeFilter = ProjectType | 'all';

@Component({
  selector: 'app-projects-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './projects-list.html',
  styleUrl: './projects-list.css',
})
export class ProjectsListComponent implements OnInit {
  projects: ProjectSummary[] = [];
  loading = true;
  error = false;

  activeFilter: TypeFilter = 'all';
  searchTerm = '';

  readonly types = ALL_PROJECT_TYPES;
  readonly projectTypeLabel = projectTypeLabel;
  readonly projectTypeIcon = projectTypeIcon;
  readonly projectDetailPath = projectDetailPath;

  constructor(private projectsService: ProjectsService) {}

  ngOnInit(): void {
    this.projectsService.getAll().subscribe({
      next: projects => { this.projects = projects; this.loading = false; },
      error: () => { this.error = true; this.loading = false; },
    });
  }

  get filteredProjects(): ProjectSummary[] {
    const term = this.searchTerm.trim().toLowerCase();
    return this.projects.filter(p =>
      (this.activeFilter === 'all' || p.type === this.activeFilter) &&
      (!term || p.title.toLowerCase().includes(term) || p.shortDescription.toLowerCase().includes(term))
    );
  }

  setFilter(filter: TypeFilter): void {
    this.activeFilter = filter;
  }
}