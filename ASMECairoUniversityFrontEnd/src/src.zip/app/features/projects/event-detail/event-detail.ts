import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ProjectsService } from '../../../core/services/projects.service';
import { EventProject, ProjectType } from '../../../core/models/project.model';
import { ProjectHeroComponent } from '../../../shared/components/project-hero/project-hero';
import { ProjectGalleryComponent } from '../../../shared/components/project-gallery/project-gallery';
import { ProjectDetailsComponent } from '../../../shared/components/project-sidebar-details/project-sidebar-details';
import { ReservationComponent } from '../../../shared/components/reservation/reservation';
import { SponsersComponent } from '../../../shared/components/sponsers/sponsers';
import { SpeakersComponent } from '../../../shared/components/speakers/speakers';
import { PartnersComponent } from '../../../shared/components/partners/partners';

@Component({
  selector: 'app-event-detail',
  standalone: true,
  imports: [
    CommonModule, ProjectHeroComponent, ProjectGalleryComponent,
    ProjectDetailsComponent, ReservationComponent, SponsersComponent, SpeakersComponent, PartnersComponent,
  ],
  templateUrl: './event-detail.html',
  styleUrls: ['./event-detail.css', '../../../shared/styles/project-detail-layout.css'],
})
export class EventDetailComponent implements OnInit {
  project: EventProject | null = null;
  loading = true;
  notFound = false;

  constructor(private route: ActivatedRoute, private projectsService: ProjectsService) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.projectsService.getById(id).subscribe({
      next: p => {
        this.loading = false;
        if (p.type === ProjectType.Event) this.project = p;
        else this.notFound = true; // wrong route prefix for this project's real type
      },
      error: () => { this.loading = false; this.notFound = true; },
    });
  }
}
