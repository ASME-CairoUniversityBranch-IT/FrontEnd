import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class LoginComponent {
  email = '';
  password = '';
  submitting = false;
  errorMessage = '';

  /** Where to send the admin back to once they're authenticated. Defaults to the create-project page,
   *  since that's the only place this form is ever linked from. */
  private returnUrl = '/projects/create';

  constructor(
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
  ) {
    const requested = this.route.snapshot.queryParamMap.get('returnUrl');
    if (requested) this.returnUrl = requested;
  }

  onSubmit(): void {
    if (!this.email.trim() || !this.password) {
      this.errorMessage = 'Please enter both an email and a password.';
      return;
    }

    this.submitting = true;
    this.errorMessage = '';

    this.authService.login({ email: this.email.trim(), password: this.password }).subscribe({
      next: () => this.router.navigateByUrl(this.returnUrl),
      error: err => {
        this.submitting = false;
        this.errorMessage = err?.status === 401
          ? 'Incorrect email or password.'
          : 'Something went wrong. Please try again.';
      },
    });
  }
}
