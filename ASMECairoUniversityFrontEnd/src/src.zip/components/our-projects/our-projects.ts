import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import * as AOS from 'aos';
import { ProjectsService } from '../../app/core/services/projects.service';
import { ProjectSummary, ProjectType } from '../../app/core/models/project.model';
import { ALL_PROJECT_TYPES, projectDetailPath, projectTypeIcon, projectTypeLabel } from '../../app/core/utils/project-route.util';

@Component({
  selector: 'app-our-project',
  imports: [CommonModule, RouterModule],
  templateUrl: './our-projects.html',
  styleUrl: './our-projects.css',
})
export class OurProject implements OnInit {
  readonly tabs = ALL_PROJECT_TYPES;
  readonly projectTypeLabel = projectTypeLabel;
  readonly projectTypeIcon = projectTypeIcon;
  readonly projectDetailPath = projectDetailPath;

  activeTab: ProjectType = ProjectType.Event;
  projects: ProjectSummary[] = [];
  loading = true;

  constructor(private projectsService: ProjectsService) {}

  ngOnInit(): void {
    AOS.init();
    this.projectsService.getAll().subscribe({
      next: projects => { this.projects = projects; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  get projectsData(): ProjectSummary[] {
    return this.projects.filter(p => p.type === this.activeTab).slice(0, 3);
  }

  switchTab(tab: ProjectType): void {
    this.activeTab = tab;
  }
}